# GamePort AI — Limitaciones (Fase 1, v0.1.0)

## Estado real
- **Implementado:** app Android nativa (Kotlin + Jetpack Compose), navegación, importación segura de ZIP, gestión de proyectos, historial y ajustes en SQLite local.
- **No implementado (la interfaz lo indica como "pendiente"):** Neural Engine (F2), Analyzer (F3), Converter (F4), Builder (F5), Test Lab (F6-8), Informes (F8). No hacen nada y no producen resultados.

## Verificación
- El código fue escrito sin poder compilarse en el entorno de desarrollo (sin acceso a los repositorios de Android/Gradle/Maven). **No se ha compilado ni probado en un dispositivo.** Puede haber errores de compilación que deban corregirse al primer build.
- Versiones elegidas según la documentación oficial de compatibilidad: AGP 8.7.3, Gradle 8.9, Kotlin 2.0.21 con el plugin del compilador de Compose, Compose BOM 2024.10.01, JDK 17, compileSdk 35, minSdk 26.

## Importación de ZIP
- El ZIP original se guarda como `original.zip` (solo lectura) y se extrae una copia en `work/`. El original nunca se modifica; las futuras fases trabajarán sobre `work/`.
- Rechaza: rutas con `..`, absolutas o con unidad, más de 50.000 entradas, ZIP > 1 GB, descomprimido > 3 GB, entradas > 1 GB, ratio > 200:1 en entradas grandes, ZIP cifrados o dañados.
- Los enlaces simbólicos no se recrean (se escribe solo contenido de archivos). No se ejecuta nada del proyecto.
- Los límites son fijos (no configurables todavía). El almacenamiento necesario es ~2-3 veces el tamaño del ZIP.
- Sin barra de progreso detallada: solo indicador indeterminado. La importación se cancela si la app se cierra.

## Alcance técnico futuro (no es una promesa)
- **Compilar juegos de PC en el móvil no es viable** de forma general: un teléfono no tiene el SDK de Android, los motores ni las toolchains de PC. Cualquier compilación (Fase 5) se evaluará caso a caso y puede requerir herramientas externas.
- **Test Lab:** no hay ningún servicio de Android en la nube verificado (SpawnDroid no se pudo confirmar). Hasta que exista una integración real, no habrá pruebas ni informes.
- **Neural Engine:** no existe ningún componente todavía. Chaquopy (Python) solo se añadirá si hace falta y se comprueba su compatibilidad.
- Los datos viven solo en el dispositivo; `allowBackup` está desactivado, así que no hay copia de seguridad automática.
