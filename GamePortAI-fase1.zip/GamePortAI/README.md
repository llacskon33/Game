# GamePort AI — Fase 1

App Android nativa (Kotlin + Jetpack Compose). Lee `LIMITATIONS.md` antes de nada.

## Compilar el APK (sin servidores de pago)
**Opción A – PC con Android Studio (recomendada):** abre esta carpeta, deja que sincronice Gradle y ejecuta *Build > Build APK(s)*. Resultado: `app/build/outputs/apk/debug/app-debug.apk`.

**Opción B – línea de comandos (JDK 17 + Android SDK con plataforma 35):**
```
./gradlew assembleDebug
```
**Opción C – opcional, GitHub Actions:** `.github/workflows/build-apk.yml` compila y sube el APK como artefacto. La app NO depende de GitHub.

El APK `debug` está firmado con la clave de depuración y se puede instalar directamente (activa "instalar apps desconocidas").

## Estructura
- `data/` SQLite (`Repository`) e importación segura (`ZipImporter`).
- `MainViewModel` estado y operaciones.
- `ui/` tema, módulos, pantallas y navegación.
