package com.gameportai.app.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.io.IOException
import java.util.UUID
import java.util.zip.ZipException
import java.util.zip.ZipFile

object ZipLimits {
    const val MAX_ZIP_BYTES = 1L * 1024 * 1024 * 1024
    const val MAX_EXTRACTED_BYTES = 3L * 1024 * 1024 * 1024
    const val MAX_ENTRY_BYTES = 1L * 1024 * 1024 * 1024
    const val MAX_ENTRIES = 50_000
    const val MAX_PATH_DEPTH = 40
    const val MAX_PATH_LENGTH = 1024
    const val MAX_RATIO = 200L
    const val RATIO_MIN_BYTES = 16L * 1024 * 1024
}

class ImportException(message: String) : Exception(message)

/**
 * Importación segura: copia el ZIP a almacenamiento privado de la app (original.zip, solo lectura)
 * y extrae una copia de trabajo (work/). Nunca ejecuta nada del ZIP.
 * Protege contra zip-slip, rutas absolutas, exceso de entradas/tamaño y bombas de compresión.
 */
object ZipImporter {

    private class Stats(val files: Int, val bytes: Long)

    fun importZip(context: Context, repo: Repository, uri: Uri): Project {
        val resolver = context.contentResolver
        var displayName = "proyecto.zip"
        var declared = -1L
        resolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val n = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (n >= 0) c.getString(n)?.let { displayName = it }
                val s = c.getColumnIndex(OpenableColumns.SIZE)
                if (s >= 0 && !c.isNull(s)) declared = c.getLong(s)
            }
        }
        if (declared > ZipLimits.MAX_ZIP_BYTES) {
            throw ImportException("El ZIP supera el límite de ${ZipLimits.MAX_ZIP_BYTES / (1024 * 1024)} MB.")
        }
        val root = File(context.filesDir, "projects").apply { mkdirs() }
        if (declared > 0 && root.usableSpace < declared * 3 + 100L * 1024 * 1024) {
            throw ImportException("Espacio insuficiente: se necesita unas 3 veces el tamaño del ZIP.")
        }
        val tmp = File(root, ".tmp-" + UUID.randomUUID())
        try {
            tmp.mkdirs()
            val zipFile = File(tmp, "original.zip")
            val input = resolver.openInputStream(uri) ?: throw ImportException("No se pudo abrir el archivo.")
            input.use { inp ->
                zipFile.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    var total = 0L
                    while (true) {
                        val n = inp.read(buf)
                        if (n < 0) break
                        total += n
                        if (total > ZipLimits.MAX_ZIP_BYTES) throw ImportException("El ZIP supera el límite de tamaño.")
                        out.write(buf, 0, n)
                    }
                }
            }
            val work = File(tmp, "work").apply { mkdirs() }
            val stats = extract(zipFile, work)
            zipFile.setReadOnly()
            val name = displayName.removeSuffix(".zip").removeSuffix(".ZIP").ifBlank { "proyecto" }
            val project = repo.insertProject(name, displayName, zipFile.length(), stats.files, stats.bytes)
            val finalDir = File(root, project.id.toString())
            if (!tmp.renameTo(finalDir)) {
                repo.deleteProject(project.id)
                throw ImportException("No se pudo guardar el proyecto en el almacenamiento local.")
            }
            repo.addHistory(project.name, "IMPORTACIÓN",
                "Importado ${project.zipName}: ${stats.files} archivos. Original conservado y copia de trabajo creada.")
            return project
        } catch (e: ImportException) {
            tmp.deleteRecursively(); throw e
        } catch (e: ZipException) {
            tmp.deleteRecursively()
            throw ImportException("El archivo no es un ZIP válido, está dañado o está cifrado (no soportado).")
        } catch (e: IOException) {
            tmp.deleteRecursively()
            throw ImportException("Error de lectura/escritura: ${e.message ?: "desconocido"}")
        } catch (e: Throwable) {
            tmp.deleteRecursively(); throw e
        }
    }

    private fun unsafe(): Nothing =
        throw ImportException("El ZIP contiene rutas no seguras. Importación rechazada.")

    private fun extract(zip: File, dest: File): Stats {
        val destCanon = dest.canonicalFile
        var files = 0
        var total = 0L
        var entries = 0
        ZipFile(zip).use { zf ->
            val en = zf.entries()
            while (en.hasMoreElements()) {
                val e = en.nextElement()
                if (++entries > ZipLimits.MAX_ENTRIES) throw ImportException("El ZIP tiene demasiadas entradas.")
                val name = e.name.replace('\\', '/')
                if (name.isEmpty() || name.contains('\u0000') || name.startsWith("/") ||
                    name.length > ZipLimits.MAX_PATH_LENGTH || Regex("^[A-Za-z]:").containsMatchIn(name)
                ) unsafe()
                val parts = name.split('/').filter { it.isNotEmpty() }
                if (parts.any { it == ".." } || parts.size > ZipLimits.MAX_PATH_DEPTH) unsafe()
                if (parts.isEmpty()) continue
                val target = File(destCanon, parts.joinToString("/")).canonicalFile
                if (!target.path.startsWith(destCanon.path + File.separator)) unsafe()
                if (e.isDirectory) { target.mkdirs(); continue }
                target.parentFile?.mkdirs()
                val cs = e.compressedSize
                var entryBytes = 0L
                zf.getInputStream(e).use { inp ->
                    target.outputStream().use { out ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = inp.read(buf)
                            if (n < 0) break
                            entryBytes += n; total += n
                            if (entryBytes > ZipLimits.MAX_ENTRY_BYTES || total > ZipLimits.MAX_EXTRACTED_BYTES) {
                                throw ImportException("El contenido descomprimido supera los límites permitidos.")
                            }
                            if (cs > 0 && entryBytes > ZipLimits.RATIO_MIN_BYTES && entryBytes / cs > ZipLimits.MAX_RATIO) {
                                throw ImportException("Posible bomba de compresión detectada. Importación rechazada.")
                            }
                            out.write(buf, 0, n)
                        }
                    }
                }
                files++
            }
        }
        return Stats(files, total)
    }
}
