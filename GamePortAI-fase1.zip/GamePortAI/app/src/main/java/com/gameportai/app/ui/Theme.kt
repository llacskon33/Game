package com.gameportai.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Cyan = Color(0xFF00E5FF)
val Violet = Color(0xFF7C4DFF)
val Green = Color(0xFF00E676)
val Amber = Color(0xFFFFB300)
val Red = Color(0xFFFF5370)

private val Scheme = darkColorScheme(
    primary = Cyan,
    onPrimary = Color(0xFF00212B),
    secondary = Violet,
    background = Color(0xFF0A0E17),
    onBackground = Color(0xFFE6EDF7),
    surface = Color(0xFF121826),
    onSurface = Color(0xFFE6EDF7),
    surfaceVariant = Color(0xFF1B2335),
    onSurfaceVariant = Color(0xFF9AA8C0),
    error = Red,
    outline = Color(0xFF2A3550),
)

@Composable
fun GamePortTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
