package com.gameportai.app

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.gameportai.app.data.HistoryEntry
import com.gameportai.app.data.ImportException
import com.gameportai.app.data.Project
import com.gameportai.app.data.Repository
import com.gameportai.app.data.ZipImporter
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(app: Application) : AndroidViewModel(app) {

    data class Notice(val text: String, val isError: Boolean)

    private val repo = Repository(app)
    private val projectsDir get() = File(getApplication<Application>().filesDir, "projects")

    var projects by mutableStateOf<List<Project>>(emptyList())
        private set
    var history by mutableStateOf<List<HistoryEntry>>(emptyList())
        private set
    var storageBytes by mutableLongStateOf(0L)
        private set
    var importing by mutableStateOf(false)
        private set
    var notice by mutableStateOf<Notice?>(null)
        private set

    init { refresh() }

    fun refresh() {
        viewModelScope.launch {
            val data = withContext(Dispatchers.IO) {
                Triple(
                    repo.projects(),
                    repo.history(200),
                    projectsDir.walkTopDown().filter { it.isFile }.sumOf { it.length() },
                )
            }
            projects = data.first; history = data.second; storageBytes = data.third
        }
    }

    fun importZip(uri: Uri) {
        if (importing) return
        importing = true
        notice = null
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching { ZipImporter.importZip(getApplication<Application>(), repo, uri) }
            }
            result.onSuccess {
                notice = Notice("Proyecto «${it.name}» importado: ${it.files} archivos. El ZIP original se conserva sin cambios.", false)
            }.onFailure { e ->
                val msg = (e as? ImportException)?.message ?: "Error inesperado (${e.javaClass.simpleName})."
                withContext(Dispatchers.IO) { repo.addHistory(null, "ERROR", "Importación fallida: $msg") }
                notice = Notice(msg, true)
            }
            importing = false
            refresh()
        }
    }

    fun deleteProject(p: Project) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                File(projectsDir, p.id.toString()).deleteRecursively()
                repo.deleteProject(p.id)
                repo.addHistory(p.name, "ELIMINACIÓN", "Proyecto eliminado por el usuario (original y copia de trabajo).")
            }
            notice = Notice("Proyecto «${p.name}» eliminado.", false)
            refresh()
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { repo.clearHistory() }
            refresh()
        }
    }
}
