package com.gameportai.app.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Project(
    val id: Long,
    val name: String,
    val zipName: String,
    val zipBytes: Long,
    val files: Int,
    val extractedBytes: Long,
    val importedAt: Long,
    val status: String,
)

data class HistoryEntry(
    val id: Long,
    val projectName: String?,
    val type: String,
    val message: String,
    val at: Long,
)

/** Almacenamiento local en SQLite (API nativa de Android, sin librerías extra). */
class Repository(context: Context) {

    private class Helper(c: Context) : SQLiteOpenHelper(c, "gameport.db", null, 1) {
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE projects(" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, zip_name TEXT NOT NULL, " +
                    "zip_bytes INTEGER NOT NULL, files INTEGER NOT NULL, extracted_bytes INTEGER NOT NULL, " +
                    "imported_at INTEGER NOT NULL, status TEXT NOT NULL)"
            )
            db.execSQL(
                "CREATE TABLE history(" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, project_name TEXT, " +
                    "type TEXT NOT NULL, message TEXT NOT NULL, at INTEGER NOT NULL)"
            )
        }

        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    }

    private val helper = Helper(context.applicationContext)

    @Synchronized
    fun projects(): List<Project> {
        val c = helper.readableDatabase.rawQuery(
            "SELECT id,name,zip_name,zip_bytes,files,extracted_bytes,imported_at,status " +
                "FROM projects ORDER BY imported_at DESC", null
        )
        return c.use {
            val out = ArrayList<Project>()
            while (it.moveToNext()) {
                out.add(Project(it.getLong(0), it.getString(1), it.getString(2), it.getLong(3),
                    it.getInt(4), it.getLong(5), it.getLong(6), it.getString(7)))
            }
            out
        }
    }

    @Synchronized
    fun insertProject(name: String, zipName: String, zipBytes: Long, files: Int, extractedBytes: Long): Project {
        val now = System.currentTimeMillis()
        val status = "Copia de trabajo lista"
        val v = ContentValues().apply {
            put("name", name); put("zip_name", zipName); put("zip_bytes", zipBytes)
            put("files", files); put("extracted_bytes", extractedBytes)
            put("imported_at", now); put("status", status)
        }
        val id = helper.writableDatabase.insertOrThrow("projects", null, v)
        return Project(id, name, zipName, zipBytes, files, extractedBytes, now, status)
    }

    @Synchronized
    fun deleteProject(id: Long) {
        helper.writableDatabase.delete("projects", "id=?", arrayOf(id.toString()))
    }

    @Synchronized
    fun addHistory(projectName: String?, type: String, message: String) {
        val v = ContentValues().apply {
            put("project_name", projectName); put("type", type)
            put("message", message); put("at", System.currentTimeMillis())
        }
        helper.writableDatabase.insertOrThrow("history", null, v)
    }

    @Synchronized
    fun history(limit: Int): List<HistoryEntry> {
        val c = helper.readableDatabase.rawQuery(
            "SELECT id,project_name,type,message,at FROM history ORDER BY at DESC, id DESC LIMIT $limit", null
        )
        return c.use {
            val out = ArrayList<HistoryEntry>()
            while (it.moveToNext()) {
                out.add(HistoryEntry(it.getLong(0), it.getString(1), it.getString(2), it.getString(3), it.getLong(4)))
            }
            out
        }
    }

    @Synchronized
    fun clearHistory() {
        helper.writableDatabase.delete("history", null, null)
    }
}
