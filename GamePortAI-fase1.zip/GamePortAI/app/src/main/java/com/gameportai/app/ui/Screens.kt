package com.gameportai.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.gameportai.app.MainViewModel
import com.gameportai.app.data.HistoryEntry
import com.gameportai.app.data.Project
import com.gameportai.app.data.ZipLimits

@Composable
private fun Pulse() {
    val t = rememberInfiniteTransition(label = "pulse")
    val a by t.animateFloat(0.35f, 1f, infiniteRepeatable(tween(1200), RepeatMode.Reverse), label = "alpha")
    Spacer(Modifier.size(10.dp).alpha(a).background(Green, CircleShape))
}

@Composable
private fun Stat(label: String, value: String, modifier: Modifier = Modifier) {
    Panel(modifier) {
        Text(value, style = MaterialTheme.typography.titleLarge, color = Cyan, fontWeight = FontWeight.Bold, maxLines = 1)
        Muted(label)
    }
}

@Composable
private fun HistoryRow(e: HistoryEntry) {
    val color = when (e.type) { "ERROR" -> Red; "IMPORTACIÓN" -> Green; else -> Amber }
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.Top) {
        Chip(e.type, color)
        Spacer(Modifier.width(10.dp))
        androidx.compose.foundation.layout.Column(Modifier.weight(1f)) {
            Text(e.message, style = MaterialTheme.typography.bodyMedium)
            Muted(Format.date(e.at) + (e.projectName?.let { " · $it" } ?: ""))
        }
    }
}

@Composable
fun DashboardScreen(vm: MainViewModel, onOpen: (Module) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Panel {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Pulse(); Spacer(Modifier.width(8.dp))
                    Text("GamePort AI · Fase 1", style = MaterialTheme.typography.titleMedium, color = Cyan)
                }
                Text("Gestión local de proyectos de videojuegos. Por ahora puedes importar ZIP de forma segura y conservar el original; el resto de módulos están pendientes y se marcan como tales.",
                    style = MaterialTheme.typography.bodyMedium)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Stat("Proyectos", vm.projects.size.toString(), Modifier.weight(1f))
                Stat("Espacio", Format.bytes(vm.storageBytes), Modifier.weight(1f))
                Stat("Eventos", vm.history.size.toString(), Modifier.weight(1f))
            }
        }
        item {
            Panel {
                SectionTitle("Módulos")
                Module.entries.forEach { m ->
                    Row(Modifier.fillMaxWidth().clickable { onOpen(m) }.padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(m.title)
                        if (m.implemented) Chip("Activo", Green) else Chip("${m.phaseLabel} · pendiente", Amber)
                    }
                }
            }
        }
        item {
            Panel {
                SectionTitle("Actividad reciente")
                if (vm.history.isEmpty()) Muted("Sin actividad todavía. Importa un ZIP para empezar.")
                else vm.history.take(5).forEach { HistoryRow(it) }
            }
        }
    }
}

@Composable
fun ImportScreen(vm: MainViewModel) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importZip(uri)
    }
    var toDelete by remember { mutableStateOf<Project?>(null) }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Panel {
                SectionTitle("Importar proyecto ZIP")
                Muted("El ZIP se copia al almacenamiento privado de la app (original de solo lectura) y se extrae una copia de trabajo. No se ejecuta nada del proyecto.")
                Button(
                    onClick = { picker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/x-zip", "application/octet-stream")) },
                    enabled = !vm.importing,
                    modifier = Modifier.fillMaxWidth(),
                ) { Text(if (vm.importing) "Importando…" else "Seleccionar ZIP") }
                if (vm.importing) LinearProgressIndicator(Modifier.fillMaxWidth())
                Muted("Límites: ZIP ${Format.bytes(ZipLimits.MAX_ZIP_BYTES)}, descomprimido ${Format.bytes(ZipLimits.MAX_EXTRACTED_BYTES)}, ${ZipLimits.MAX_ENTRIES} entradas.")
            }
        }
        vm.notice?.let { n ->
            item { Panel { Text(n.text, color = if (n.isError) Red else Green) } }
        }
        item { SectionTitle("Proyectos (${vm.projects.size})") }
        if (vm.projects.isEmpty()) item { Muted("Todavía no hay proyectos importados.") }
        items(vm.projects, key = { it.id }) { p ->
            Panel {
                Text(p.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Muted("${p.zipName} · ${Format.bytes(p.zipBytes)} · ${p.files} archivos · ${Format.bytes(p.extractedBytes)} descomprimido")
                Muted("Importado: ${Format.date(p.importedAt)}")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Chip(p.status, Green)
                    TextButton(onClick = { toDelete = p }) { Text("Eliminar", color = Red) }
                }
            }
        }
    }

    toDelete?.let { p ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("¿Eliminar «${p.name}»?") },
            text = { Text("Se borrarán el ZIP original y la copia de trabajo de este dispositivo. No se puede deshacer.") },
            confirmButton = { TextButton(onClick = { vm.deleteProject(p); toDelete = null }) { Text("Eliminar", color = Red) } },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancelar") } },
        )
    }
}

@Composable
fun PendingScreen(module: Module, vm: MainViewModel) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Panel {
                Chip("No implementado · ${module.phaseLabel}", Amber)
                Text(module.title, style = MaterialTheme.typography.titleLarge)
                Text(module.planned, style = MaterialTheme.typography.bodyMedium)
            }
        }
        item {
            Panel {
                SectionTitle("Estado actual")
                Muted("Este módulo no hace nada todavía y no genera resultados. Proyectos disponibles para trabajos futuros: ${vm.projects.size}.")
            }
        }
    }
}

@Composable
fun HistoryScreen(vm: MainViewModel) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (vm.history.isEmpty()) item { Panel { Muted("El historial está vacío.") } }
        items(vm.history, key = { it.id }) { Panel { HistoryRow(it) } }
    }
}

@Composable
fun SettingsScreen(vm: MainViewModel) {
    var confirm by remember { mutableStateOf(false) }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Panel {
                SectionTitle("Almacenamiento")
                Text("${Format.bytes(vm.storageBytes)} usados por ${vm.projects.size} proyecto(s). Todo se guarda de forma privada en este dispositivo.")
            }
        }
        item {
            Panel {
                SectionTitle("Límites de importación (fijos en esta versión)")
                Muted("ZIP: ${Format.bytes(ZipLimits.MAX_ZIP_BYTES)} · Descomprimido: ${Format.bytes(ZipLimits.MAX_EXTRACTED_BYTES)}")
                Muted("Entradas: ${ZipLimits.MAX_ENTRIES} · Profundidad: ${ZipLimits.MAX_PATH_DEPTH} · Ratio máx.: ${ZipLimits.MAX_RATIO}:1")
            }
        }
        item {
            Panel {
                SectionTitle("Datos")
                OutlinedButton(onClick = { confirm = true }, modifier = Modifier.fillMaxWidth()) { Text("Borrar historial") }
                Muted("Borrar el historial no elimina los proyectos.")
            }
        }
        item {
            Panel {
                SectionTitle("Limitaciones conocidas")
                Muted("• Solo Fase 1: importar, guardar y gestionar proyectos. No analiza, convierte, compila ni prueba.")
                Muted("• Un teléfono no puede compilar juegos de PC directamente a Android.")
                Muted("• Los ZIP cifrados con contraseña no están soportados.")
                Muted("• Versión 0.1.0. Detalle completo en LIMITATIONS.md.")
            }
        }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("¿Borrar el historial?") },
            text = { Text("Se eliminarán todos los eventos registrados. Los proyectos se conservan.") },
            confirmButton = { TextButton(onClick = { vm.clearHistory(); confirm = false }) { Text("Borrar", color = Red) } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancelar") } },
        )
    }
}
