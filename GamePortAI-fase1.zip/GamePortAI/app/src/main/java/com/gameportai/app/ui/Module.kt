package com.gameportai.app.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.ui.graphics.vector.ImageVector

enum class Module(
    val title: String,
    val icon: ImageVector,
    val phaseLabel: String,
    val implemented: Boolean,
    val planned: String,
) {
    DASHBOARD("Dashboard", Icons.Default.Home, "Fase 1", true, ""),
    IMPORT("Importar juego", Icons.Default.Add, "Fase 1", true, ""),
    ANALYZER("Analyzer", Icons.Default.Search, "Fase 3", false,
        "Identificará el motor del juego, los lenguajes, las dependencias y las incompatibilidades, y generará un mapa interno del proyecto. Hoy solo puedes importar y guardar proyectos."),
    NEURAL("Neural Engine", Icons.Default.Star, "Fase 2", false,
        "Cerebro propio y local: memoria técnica, memoria de experiencias, planificador y evaluación de soluciones. Todavía no existe ningún componente de este motor."),
    CONVERTER("Converter", Icons.Default.Share, "Fase 4", false,
        "Propondrá y aplicará cambios controlados sobre la copia de trabajo (primero proyectos Godot de PC a Android). El original nunca se modifica."),
    BUILDER("Builder", Icons.Default.Build, "Fase 5", false,
        "Compilación de APK. Limitación conocida: un teléfono no puede compilar juegos de PC directamente; la viabilidad real se evaluará antes de implementarlo (ver LIMITATIONS.md)."),
    TESTLAB("Test Lab", Icons.Default.Check, "Fases 6-8", false,
        "Pruebas sobre un dispositivo Android. Aún no hay ningún servicio de pruebas verificado, y no se mostrarán resultados hasta que existan pruebas reales."),
    HISTORY("Historial", Icons.Default.DateRange, "Fase 1", true, ""),
    REPORTS("Informes", Icons.Default.Info, "Fase 8", false,
        "Informes finales de adaptación y pruebas, generados solo a partir de resultados reales."),
    SETTINGS("Configuración", Icons.Default.Settings, "Fase 1", true, ""),
}
